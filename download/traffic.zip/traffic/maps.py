import random
import json
import inspect
from itertools import product, groupby, chain

from lights import TrafficLight, TrafficLightSystem
from road import Road
from roadmap import RoadMap
from storage import Storage
from vector import plus, minus, times, over, dot, transform, norm, unit, distance

def funcname():
    return inspect.stack()[1][3]


def trafficlighttest(scale=25):
    lights = set()
    roads = set()
    for edge in [(( 0,-1), ( 0, 1), True),
                 ((-1, 0), ( 1, 0), True),
                 ((-1,-5), ( 0,-1), False),
                 ((-5,-1), (-1, 0), False),
                 (( 0, 1), ( 1, 5), False),
                 (( 1, 0), ( 5, 1), False)]:
        road = Road(times(scale, plus(5, edge[0])),
                    times(scale, plus(5, edge[1])))
        roads.add(road)
        if edge[2]:
            light = TrafficLight(road)
            lights.add(light)
            road.light = light
    system = TrafficLightSystem(lights)
    roadmap = RoadMap(roads, set([system]))
    return roadmap

def speedlimittest(scale=25):
    roads = set(Road(times(scale, edge[0]),
                     times(scale, edge[1]),
                     edge[2]) for edge in
                [(( 0, 0), (30, 0), 10),
                 (( 0, 5), (10, 5), 10),
                 ((10, 5), (20, 5), 20),
                 ((20, 5), (30, 5), 10),
                 (( 0,10), (30,10), 20)])
    return RoadMap(roads, set())

# generate a manhattanish roadmap of size^2 junctions
def manhattanoid(size, scale=10, offset=0, strategy=None):
    def junction_outs(j):
        return tuple(plus(j, q) for q in (( 1, 2), (2,-1), (-1,-2), (-2, 1)))
    def junction_ins(j):
        return tuple(plus(j, q) for q in ((-1, 2), (2, 1), ( 1,-2), (-2,-1)))

    dist = 15 # junction-to-junction distance
    offset += dist # make sure everything is in the first quadrant

    roads = set()
    systems = set()

    randomize = lambda x: x + random.randint(0, dist/3)
    #randomize = lambda x : x
    jss = map(lambda x: map(lambda y: map(randomize, (x, y)),
                            range(0, size*dist, dist)),
              range(0, size*dist, dist))


    for (x, y) in product(range(size), repeat=2):
        ins  = junction_ins(jss[x][y])
        outs = junction_outs(jss[x][y])

        lights = set()
        junction_edges = list(product(ins, outs))
        for edge in junction_edges:
            road = Road(times(scale, plus(offset, edge[0])),
                        times(scale, plus(offset, edge[1])),
                        light=True, limit=5)
            lights.add(road.light)
            roads.add(road)
        systems.add(TrafficLightSystem(lights, strategy=strategy))

        edges = [
            # connections outward
            (outs[0], junction_ins(jss[x][y+1] if y+1 < size else plus(jss[x][y], ( 0, dist)))[2]),
            (outs[1], junction_ins(jss[x+1][y] if x+1 < size else plus(jss[x][y], ( dist, 0)))[3]),
            (outs[2], junction_ins(jss[x][y-1] if y-1 >= 0   else plus(jss[x][y], ( 0,-dist)))[0]),
            (outs[3], junction_ins(jss[x-1][y] if x-1 >= 0   else plus(jss[x][y], (-dist, 0)))[1]),
            
            # connections inward (most of the time redundant, but otherwise the
            # fringe junctions will look limp)
            (junction_outs(jss[x][y+1] if y+1 < size else plus(jss[x][y], ( 0, dist)))[2], ins[0]),
            (junction_outs(jss[x+1][y] if x+1 < size else plus(jss[x][y], ( dist, 0)))[3], ins[1]),
            (junction_outs(jss[x][y-1] if y-1 >= 0   else plus(jss[x][y], ( 0,-dist)))[0], ins[2]),
            (junction_outs(jss[x-1][y] if x-1 >= 0   else plus(jss[x][y], (-dist, 0)))[1], ins[3]),
            ]
        for edge in edges:
            roads.add(Road(times(scale, plus(offset, edge[0])),
                           times(scale, plus(offset, edge[1]))))
            
    return RoadMap(roads, systems, name=funcname(), dims=size)

# generate a manhattanish roadmap of size^2 junctions with turning lanes
def manhattanoid_with_turning_lanes(size, scale=5, offset=0, strategy=None):
    dist = 30 # junction-to-junction distance
    offset += dist # make sure everything is in the first quadrant

    # pivot pi/2 clockwise about the origin
    def pivot_vector(p):
        return transform(p, ((0, -1),
                             (1,  0)))
    def pivot_edges(edges):
        return [map(pivot_vector, e) for e in edges]

    def absolutify(p):
        return times(scale, plus(offset, p))
    
    # in/out order matters: south east north west side of the junction
    def junction_ins(p):
        return [absolutify(plus(p, i)) for i in [(1, 8), (8, -1), (-1, -8), (-8, 1)]]
    def junction_outs(p):
        return [absolutify(plus(p, o)) for o in [(-1, 8), (8, 1), (1, -8), (-8, -1)]]

    def junction_turning_lanes(p):
        # from north
        north_edges = [((-1, -8), (-1.5, -4)), # right turning lane
                       ((-1, -8), (-1,   -4)), # straight turning lane
                       ((-1, -8), (-0.5, -4)), # left turning lane
                       (( 1, -4), ( 1,   -8))] # out lane
        east_edges = pivot_edges(north_edges)
        south_edges = pivot_edges(east_edges)
        west_edges = pivot_edges(south_edges)
        return [tuple(absolutify(plus(p, jss[x][y])) for p in e) for e in
                chain(north_edges, east_edges, south_edges, west_edges)]

    def junction_lit_edges(p):
        # from north
        north_edges = [#(( 1,  -4), ( 2, -4)), # u-turn
                       ((-0.5,  -4), ( 4,  1)), # left turn
                       ((-1,    -4), (-1,  4)), # straight
                       ((-1.5,  -4), (-4, -1))] # right turn
        east_edges = pivot_edges(north_edges)
        south_edges = pivot_edges(east_edges)
        west_edges = pivot_edges(south_edges)
        return [tuple(absolutify(plus(p, jss[x][y])) for p in e) for e in
                chain(north_edges, east_edges, south_edges, west_edges)]

    roads = set()
    systems = set()

    randomize = lambda x: x + random.random()*dist/3.0
    jss = map(lambda x: map(lambda y: map(randomize, (x, y)),
                            range(0, size*dist, dist)),
              range(0, size*dist, dist))

    for (x, y) in product(range(size), repeat=2):
        jins   = junction_ins(jss[x][y])
        jouts  = junction_outs(jss[x][y])
        jturns = junction_turning_lanes(jss[x][y])
        jedges = junction_lit_edges(jss[x][y])

        lights = set()
        for edge in jedges:
            road = Road(edge[0], edge[1],
                        light=True, limit=5)
            lights.add(road.light)
            roads.add(road)
        systems.add(TrafficLightSystem(lights, strategy=strategy))

        for edge in jturns:
            roads.add(Road(edge[0], edge[1], limit=5))

        connections = [
            # outward
            (jouts[0], junction_ins(jss[x][y+1] if y+1 < size else plus(jss[x][y], ( 0, dist)))[2]),
            (jouts[1], junction_ins(jss[x+1][y] if x+1 < size else plus(jss[x][y], ( dist, 0)))[3]),
            (jouts[2], junction_ins(jss[x][y-1] if y-1 >= 0   else plus(jss[x][y], ( 0,-dist)))[0]),
            (jouts[3], junction_ins(jss[x-1][y] if x-1 >= 0   else plus(jss[x][y], (-dist, 0)))[1]),
            
            # inward (most of the time redundant, but otherwise the
            # fringe junctions will look limp)
            (junction_outs(jss[x][y+1] if y+1 < size else plus(jss[x][y], ( 0, dist)))[2], jins[0]),
            (junction_outs(jss[x+1][y] if x+1 < size else plus(jss[x][y], ( dist, 0)))[3], jins[1]),
            (junction_outs(jss[x][y-1] if y-1 >= 0   else plus(jss[x][y], ( 0,-dist)))[0], jins[2]),
            (junction_outs(jss[x-1][y] if x-1 >= 0   else plus(jss[x][y], (-dist, 0)))[1], jins[3]),
            ]
        for edge in connections:
            roads.add(Road(edge[0], edge[1]))
            
    return RoadMap(roads, systems, name=funcname(), dims=size)


# generate a roadmap consisting of quadrilatals, with size**2 junctions
# NB: only one-way streets
def quadrilateraloid(size=10, scale=0, strategy=None):
    junctions = []
    roads = []
    systems = set() 
    dist = 200 #avg distance between junctions
    j_dim = 10 # radius into which a junction fits
    for y in range(size):
        for x in range(size):
            min_x, max_x = x * dist + j_dim, (x + 1) * dist - j_dim
            min_y, max_y = y * dist + j_dim, (y + 1) * dist - j_dim
            c = random.randint(min_x, max_x), random.randint(min_y, max_y)
            junction = Storage({'n': (c[0], c[1]-j_dim),
                                'e': (c[0]+j_dim, c[1]),
                                's': (c[0], c[1]+j_dim),
                                'w': (c[0]-j_dim, c[1])})
            junctions.append(junction)
    def add_road(start, end, partition=None, light=False):
        road = Road(start, end, light=light)
        roads.append(road)
        if partition is not None:
            partition.add(road.light)

    for j in junctions:
        partition = set()
        for (start, end) in [(j.s, j.w), 
                             (j.s, j.n),
                             (j.e, j.w),
                             (j.e, j.n)]:
            add_road(start, end, partition=partition, light=True)
        systems.add(TrafficLightSystem(partition, strategy=strategy))
    for x in range(size):
        for y in range(size):
            center = junctions[y*size+x]
            upper = junctions[(y-1)*size+x]
            left = junctions[y*size+x-1]
            if  0 == x == y:# or x == y == size-1:
                continue
            if y == 0 or x == size-1:
                add_road(center.w, left.e)
            elif x == 0 or y == size-1:
                add_road(center.n, upper.s)
            else:
                add_road(center.w, left.e)
                add_road(center.n, upper.s)
    return RoadMap(roads, systems=systems, name=funcname(), dims=size)


def json_map_import(json_file='testmap.json', size=0, dims=0, scale=1, strategy=None):
    file = open(json_file, 'r')
    map = json.loads(file.read())

    nodes = map['nodes']
    edges = map['edges']
    
    roads = []

    #Iterate over all edges and create a road for each one
    for edge_id in edges:
        edge =  edges[edge_id]
        start_node_id = edge['nodes']['start']
        start_node = nodes[str(start_node_id)]
        start_coords = (start_node['coordinates']['x'] * scale, start_node['coordinates']['y'] * scale)
        end_node_id = edge['nodes']['end']
        end_node = nodes[str(end_node_id)]
        end_coords = (end_node['coordinates']['x'] * scale, end_node['coordinates']['y'] * scale)
        road = Road(start_coords, end_coords)
        roads.append(road)
    

    return RoadMap(roads, name=funcname(), dims=size)

def quadrilateraloid_unregulated(size=10, scale=0, strategy=None):
    junctions = []
    roads = []
    dist = 200 #avg distance between junctions
    for x in range(size):
        for y in range(size):
            min_x, max_x = x * dist, (x + 1) * dist
            min_y, max_y = y * dist, (y + 1) * dist
            p = random.randint(min_x, max_x), random.randint(min_y, max_y)
            junctions.append(p)
    for x in range(size-1):
        for y in range(size-1):
            vert_x, vert_y = junctions[x*size+y], junctions[x*size+y+1]
            #if x == size - 1 and y == size - 1:
            #    roads.append(Road(vert_x, vert_y))
            roads.append(Road(vert_y, vert_x))
            horz_x, horz_y = junctions[x*size+y], junctions[(x+1)*size+y]
            #if x == size - 1 and y == size - 1:
            #    roads.append(Road(horz_x, horz_y))
            roads.append(Road(horz_y, horz_x))
    return RoadMap(roads, name=funcname(), dims=size)
