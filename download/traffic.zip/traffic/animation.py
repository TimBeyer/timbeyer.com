import math
import operator
import pygame
import random
from time import time

from cache import cache
from collections import deque
from vector import plus, minus, times, over, dot, transform, norm, unit, distance
from itertools import islice, starmap
from functools import partial
from operator import itemgetter
from util import normalize_series
from gui.component import Sidebar, Overview, Grid, LiveGraph, MenuBar
from strategies import *
from maps import *
from simulation import Simulation

class Animation(object):
    ZOOM_RATE = 0.1
    BACKGROUND_COLOR, FOREGROUND_COLOR  = (0, 0, 0), (255, 255, 255)
    ROAD_COLOR = (64, 64, 64)

    def __init__(self, roadmap):
        self.scale = 1
        self.detail_zoom_level = 4
        self.max_zoom_level = 10
        self.min_zoom_level = 0.25
        self.viewport_size = (1920, 1080)
        self.sidebar_width = 200
        
        pygame.init()
        self.seticon()
        self.screen = pygame.display.set_mode(self.viewport_size, pygame.FULLSCREEN)
        pygame.display.set_caption("Traffic Sim v3.0")
        self.clock = pygame.time.Clock()
        self.RUNNING = False
        self.simulation = Simulation(roadmap, 1)
        self.setup(roadmap)

    def setup(self, roadmap):
        self.show_car_info = False
        self.top_speed = 1
        self.roadmap = roadmap
        self.map_offset = roadmap.origin
        self.map_size = roadmap.size
        self.map_surface = None
        self.viewport_offset = minus(times(0.5, self.map_size),
                                     times(0.5, self.viewport_size))

        self.components = {}
        self.selected_road = None 

        # only updated every now and then (through the observer mechanism)
        self.stats = "avg_delay mov_avg_throughput avg_velocity".split()
        self.stats_over_time = deque()
        self.stat_timesteps = 100
        # all-time extremes
        inf = float("inf")
        self.stat_min = [ inf for s in self.stats]
        self.stat_max = [-inf for s in self.stats]
        
        # gui stuff
        self.map_surface = self.make_map_surface()

        sidebar = Sidebar(self, (self.sidebar_width, self.viewport_size[1]),zindex=1)
        sidebar.parent_surface = self.screen
        sidebar.set_position((self.viewport_size[0] - self.sidebar_width, 20))
        self.components['sidebar'] = sidebar

        overlay = MenuBar(self, (self.viewport_size[0], self.viewport_size[1]),zindex=2)
        overlay.parent_surface = self.screen
        overlay.set_position((0,0))
        self.components['overlay'] = overlay

        for component in self.components.values():
            component.auto_resize()

    def start(self, simulation, dt):
        del self.simulation
        self.simulation = simulation
        self.setup(self.simulation.roadmap)
        self.simulation.observers.append(self)
        self.RUNNING = True
        while self.RUNNING:
            self.simulation.advance(dt)
            self.update(simulation)
        self.screen.fill(Animation.BACKGROUND_COLOR)
        
    def update(self, simulation, max_fps=-1):
        self.check_ui_inputs()
        self.gui_update(simulation)
        self.clock.tick(max_fps)

    def gui_update(self, simulation):
        for component in self.components.values():
            component.update()
        self.draw_screen(self.screen, simulation)

    def restart(self, strategy=CherryPickingStrategy, roadmap=manhattanoid_with_turning_lanes, size=1, ncars=100):
        self.RUNNING = False
        rmap = roadmap(size=size, scale=10, strategy=strategy)
        simulation = Simulation(rmap, ncars, populate_instantly=True)
        self.setup(rmap)
        self.start(simulation, 0.5)

    def quit(self):
        self.RUNNING = False

        
    def observe(self, simulation):
        stats = [getattr(simulation, stat)() for stat in self.stats]
        self.stats_over_time.append(stats)
        if len(self.stats_over_time) > self.stat_timesteps:
            self.stats_over_time.popleft()
        self.stat_min = map(min, self.stat_min, stats)
        self.stat_max = map(max, self.stat_max, stats)
    
    def seticon(self):
        icon=pygame.Surface((40, 40))
        rawicon=pygame.image.load('car_icon.png')
        for i in range(icon.get_width()):
            for j in range(icon.get_height()):
                icon.set_at((i,j), rawicon.get_at((i,j)))
        pygame.display.set_icon(icon)

    def draw_screen(self, screen, simulation):
        screen.fill(Animation.BACKGROUND_COLOR)
        # map and grid in background
        self.map_surface.set_colorkey(pygame.Color('black'))
        screen.blit(self.map_surface, (0, 0), self.viewport_offset + self.viewport_size)
        # traffic light controlled roads
        for system in simulation.roadmap.systems:
            for light in system.traffic_lights:
                ps = [self.map_pos_to_viewport_pos(p) for p in (light.road.start, light.road.end)]
                if any(self.is_visible(p) for p in ps):
                    pygame.draw.circle(screen, pygame.Color(light.state), map(int, ps[0]), int(round(3*self.scale)))
        # visible cars
        self.top_speed = max([car.v for car in simulation.cars] + [1])
        for road in self.roadmap.roads:
            p1 = self.map_pos_to_viewport_pos(road.start)
            p2 = self.map_pos_to_viewport_pos(road.end)
            if self.is_visible(p1) or self.is_visible(p2):
                for car in road.cars:
                    pos = self.map_pos_to_viewport_pos(car.abspos())
                    self.draw_car(screen, car, pos, self.top_speed)
                    self.draw_car_lines(screen, car, pos)            
                    if self.show_car_info:
                        self.draw_car_info(screen, car, pos) 
        
        sorted_components = sorted(self.components.values(), key=lambda c: c.zindex)
        for component in sorted_components:
            component.draw()

        # scale bottom left
        scale_pos = 20, self.viewport_size[1] - 40
        self.draw_scale(scale_pos, screen)
        # overlay top left
        #self.draw_overlay(screen, self.clock.get_fps(), simulation)
        pygame.display.flip()

    def draw_scale(self, position, screen):
        width = 100
        height = 10
        surface = pygame.Surface((110, 30))
        surface.set_colorkey(pygame.Color('black'))
        color = pygame.Color('white')
        pygame.draw.line(surface, color, (0, height/2), (width, height/2))
        pygame.draw.line(surface, color, (0, 0), (0, height))
        pygame.draw.line(surface, color, (width, 0), (width, height))
        font = pygame.font.SysFont("Verdana", 18)
        text = '%.0fm' % (100/self.scale, )
        rendered_font = font.render(text, True, color)
        surface.blit(rendered_font, (width/3, height))
        screen.blit(surface, position)
 
    def draw_overview(self, position, surface):
        self.overview.update()
        surface.blit(self.overview.get(), position)

    def draw_overlay(self, screen, framerate, simulation):
        font = pygame.font.SysFont("Verdana", 12)
        age = minutes, seconds = int(simulation.age / 60), simulation.age % 60
        text = "".join(s.rjust(10) for s in
                        (
                         "%01dm%02ds" % age,
                         "%s cars" % len(simulation.cars)))
        rendered_font = font.render(text, True,
                                Animation.FOREGROUND_COLOR,
                                Animation.BACKGROUND_COLOR)
        rendered_font.set_colorkey(pygame.Color('black'))
        screen.blit(rendered_font, (0, 0))

    def check_ui_inputs(self):
        for event in pygame.event.get():
            if event.type == pygame.MOUSEMOTION and event.buttons[0] == 1:
                self.viewport_offset = minus(self.viewport_offset, event.rel)
                
            elif event.type == pygame.VIDEORESIZE:
                self.viewport_size = event.size
                self.components['sidebar'].set_position((self.viewport_size[0] - self.sidebar_width, 0))
                screen = pygame.display.set_mode(self.viewport_size, pygame.RESIZABLE)
                for component in self.components.values():
                    component.auto_resize()
                
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # Left Mouse Button
                if event.button == 1:
                    clicked_road = self.find_clicked_element(event.pos)
                    self.selected_road = clicked_road if clicked_road else self.selected_road
                    self.map_surface = self.make_map_surface()
                    self.components['sidebar'].instant_update()
                    for component in self.components.values():
                        component.receive_click(event.pos)

                # Right Mouse Button
                if event.button == 3:
                    #self.center_view_on(event.pos)
                    self.selected_road = None
                    self.map_surface = self.make_map_surface()
                    self.components['sidebar'].instant_update()
                #Scroll up ( zoom in)
                if event.button == 4:
                    if self.scale < self.max_zoom_level:   
                        self.zoom(Animation.ZOOM_RATE, event.pos)
                #Scroll down ( zoom out)     
                elif event.button == 5:
                    self.zoom(-Animation.ZOOM_RATE, event.pos)
                            
            elif event.type == pygame.QUIT:
                self.quit()
                return
                
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    self.quit()
                    return
                elif event.key == pygame.K_PAGEUP:
                    if self.scale < self.max_zoom_level:   
                        self.zoom(Animation.ZOOM_RATE, times(0.5, self.viewport_size))
                elif event.key == pygame.K_PAGEDOWN:
                    self.zoom(-Animation.ZOOM_RATE, times(0.5, self.viewport_size))

    def find_clicked_element(self, pos):
        pos_on_map = self.viewport_pos_to_map_pos(pos)
        roads = self.roadmap.roads_near_pos(pos_on_map)
        return random.choice(roads) if roads else None       

    def zoom(self, zoom, pos):
        if self.scale < self.max_zoom_level:                        
            prescale_map_point = self.viewport_pos_to_map_pos(pos)
            
            if zoom > 0:
                self.scale *= 1 + zoom
            elif zoom < 0:
                self.scale /= 1 - zoom
            
            postscale_map_point = self.map_pos_to_viewport_pos(prescale_map_point)
            difference = minus(pos, postscale_map_point)
            self.viewport_offset = minus(self.viewport_offset, difference)
            
            
            self.map_surface = self.make_map_surface()
            if self.scale > self.detail_zoom_level:
                self.show_car_info = True
            else:
                self.show_car_info = False

    def make_map_surface(self):
        map_surface = pygame.Surface(times(self.scale, self.map_size))
        map_surface.fill(Animation.BACKGROUND_COLOR)
        for road in self.roadmap.roads:
            color = Animation.ROAD_COLOR
            width = 1
            if road is self.selected_road:
                color = pygame.Color('Orange')
                width = 1
            pygame.draw.line(map_surface, color,
                              times(self.scale, minus(road.start, self.map_offset)),
                              times(self.scale, minus(road.end,   self.map_offset)),width)
        return map_surface

    def draw_car_lines(self, screen, car, pos):
        direction = transform(car.road._direction, ((0, -1),(1, 0)))
        if car.a < 0:
            scalar = min(car.a / -car.driver.b, 1)
            #scalar = min(-4 * car.a, 1)
            hue = int(min(255 - scalar * 255, 255))
            color = pygame.Color(255, hue, hue)
            pygame.draw.line(screen, color, pos, plus(pos, times(direction,-scalar * 20 * self.scale)))
        else: 
            scalar = min(car.a / car.driver.a, 1)
            hue = int(min(255 - scalar * 255, 255))
            color = pygame.Color(hue, hue, 255)
            pygame.draw.line(screen, color, pos, plus(pos, times(direction,scalar * 20 * self.scale)))

    def draw_car_info(self, screen, car, pos):
        text = "v=%.2f a=%.2f delta_x=%.2f delta_v=%.2f" % ((car.v, car.a) + car.dcif())
        font = pygame.font.SysFont("Courier New", 12)
        font_surface = font.render(text, True,
                        Animation.FOREGROUND_COLOR)
        #angle = ((math.acos(car.road._direction[0])/(math.pi*2))*360)-90        
        #font_surface = pygame.transform.rotate(font_surface, angle)
        screen.blit(font_surface,
            plus(pos,(15,15)))
            
    def draw_car(self, screen, car, pos, max_speed):
        if False: # visualizing acceleration
            if car.a < 0:
                #scalar = min(car.a / -car.driver.b, 1)
                scalar = min(-4 * car.a, 1)
                hue = int(min(255 - scalar * 255, 255))
                color = pygame.Color(255, hue, hue)
            else: 
                scalar = min(car.a / car.driver.a, 1)
                hue = int(min(255 - scalar * 255, 255))
                color = pygame.Color(hue, hue, 255)
        else: # visualizing speed
            scalar = car.v / max_speed
            hue = int(min(scalar * 255, 255))
            color = pygame.Color(255, hue, hue) 
        area = times(self.scale, (3, 3))
        screen.fill(color, minus(pos, times(0.5, area)) + area)
    
    def is_visible(self, pos):
        return all(map(operator.le, pos, self.viewport_size)) and \
            all(map(operator.ge, pos, (0, 0)))

    def center_view_on(self, pos):
        self.viewport_offset = plus(pos, times(-0.5, self.viewport_size))
     
    def map_pos_to_viewport_pos(self, map_pos):
        # after profiling, the above seems to be abnormally slow: 
        # vector.biminus seems to be the culprit
        return tuple((mp - mo) * self.scale - vo for (mp, mo, vo) in \
                         zip(map_pos, self.map_offset, self.viewport_offset))

    def viewport_pos_to_map_pos(self, viewport_pos):
        return tuple((vp + vo) / self.scale + mo for (vp, vo, mo) in \
                         zip(self.viewport_offset, viewport_pos, self.map_offset))





