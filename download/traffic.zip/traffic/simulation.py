from random import gauss, choice
from numpy import mean, array
from math import isnan

from collections import deque
from operator import methodcaller, attrgetter
from itertools import ifilterfalse, chain, islice, cycle

from util import normalize_series
from vector import dot, unit
from car import Car
from drivers import CarDriver
from models import IDM
from routing import Route
import routing

class Simulation(object):
    observation_dt = 3

    def __init__(self, roadmap, ncars, observers=None, populate_instantly=False):
        if observers is not None:
            self.observers = observers
        else:
            self.observers = []
        self.roadmap = roadmap
        self.cars = []
        self.ncars = ncars
        self.ncars_done = 0
        self.age = 0

        self.route_update_rate = 60 # update every 60 sim time seconds

        self.ncars_done_since_observation = 0
        self.historical_avg_delays = [] # delays of cars that are done
        self.historical_throughputs_weights = unit(normalize_series(range(50), 0, 10))
        self.historical_throughputs = deque([0]*len(self.historical_throughputs_weights))


        self.observation_age = 0

        if populate_instantly:
            self.populate(anywhere=True)
    def advance(self, dt):
        self.age += dt
        if self.age % self.route_update_rate == 0:
            routing.empty_cache()
        self.roadmap.advance(dt, self.age)
        map(methodcaller('advance', dt, self.age), self.cars)

        done_cars = filter(methodcaller('done'), self.cars)
        self.ncars_done += len(done_cars)
        self.ncars_done_since_observation += len(done_cars)
        self.historical_avg_delays.extend(map(methodcaller('delay'), done_cars))
        self.historical_throughputs.append(self.throughput())
        if len(self.historical_throughputs) > len(self.historical_throughputs_weights):
            self.historical_throughputs.popleft()

        if self.observation_age + Simulation.observation_dt < self.age:
            map(methodcaller('observe', self), self.observers)
            self.observation_age = self.age
            self.ncars_done_since_observation = 0

        self.cars = list(ifilterfalse(methodcaller('done'), self.cars))
        self.populate()
    def populate(self, anywhere=False):
        while len(self.cars) < self.ncars:
            car = self.make_car(anywhere=anywhere)
            if not car:
                break
            self.cars.append(car)
    def make_car(self, anywhere=False):
        if anywhere:
            # not really anywhere, but mehh
            entrance = choice(self.roadmap.roads_by_start.keys())
            exit = self.roadmap.random_exit()
        else:
            entrance = self.roadmap.random_entrance()
            exit = self.roadmap.random_exit()
        if not entrance or not exit or entrance is exit:
            return None 
        model = IDM(1.2, .9, .8)
        #model = IDM(gauss(1.2, .1), gauss(.9, .1), gauss(.8, .1))
        driver = CarDriver(model)
        route = Route(self.roadmap, entrance, exit)
        return Car(driver, route)

    # statistics
    def avg_delay(self):
        return mean(list(ifilterfalse(isnan, map(methodcaller('delay'), self.cars)))) \
            if self.cars else 0
    def mov_avg_throughput(self):
        return dot(self.historical_throughputs, self.historical_throughputs_weights)
    def throughput(self):
        return self.ncars_done_since_observation / Simulation.observation_dt
    def avg_velocity(self):
        return mean(map(attrgetter('v'), self.cars)) if self.cars else 0
    def cum_avg_throughput(self):
        return self.ncars_done / self.age if self.age else 0
    def cum_avg_delay(self):
        return mean(list(chain(self.historical_avg_delays,
                               ifilterfalse(isnan, map(methodcaller('delay'), self.cars))))) \
                               if self.cars or self.historical_avg_delays else 0
