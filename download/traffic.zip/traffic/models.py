from math import sqrt

class IDM(object):
    def __init__(self, a=1.2, b=0.9, T=0.8):
        self.a = a
        self.b = b
        self.T = T
        self.two_sqrt_ab = 2 * sqrt(self.a * self.b)

    def acceleration(self, desired_v, v, s, delta_v, s0, s1):

        delta = 4
        s_star = s0 \
                + s1 * sqrt(v / desired_v) \
                + self.T * v \
                + (v * delta_v) / (self.two_sqrt_ab)
        return self.a * (1 - (v / desired_v)**delta - (s_star / s)**2)

