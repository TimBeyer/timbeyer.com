import random
from itertools import chain

inf = float('inf')

class TrafficLightStrategy(object):
    def __init__(self):
        self.min_green_time = 30 # minimum time in seconds the lights stay green
        self.min_yellow_time = 6
    def advance(self, dt, t, independent_sets):
        pass


class RandomStrategy(TrafficLightStrategy):
    """a random light is switched"""
    def select(self, independent_sets):
        return random.choice(independent_sets)


class GreedyStrategy(TrafficLightStrategy):
    """the traffic light with the most cars is green"""
    def select(self, independent_sets):
        max_cars = None, None
        for s in independent_sets:
            total_cars = sum(len(light.cars) for light in s)
            if total_cars > max_cars[0]:
                max_cars = total_cars, s
        return max_cars[1]

# this is not the self-organizing strategy; it is more similar to the
# cutoff strategy discussed in that paper
class CutoffStrategy(TrafficLightStrategy):
    """the traffic light with at least *threshold* cars 
    gets to turn green. If no light has that many cars, 
    a random one switches"""
    def __init__(self):
        TrafficLightStrategy.__init__(self)
        self.threshold = 10
    def select(self, independent_sets):
        max_cars = None, None
        for s in independent_sets:
            total_cars = sum(len(light.cars) for light in s)
            if total_cars > self.threshold:
                return s
        # if no light has more cars than the threshold, pick one randomly
        return random.choice(independent_sets)

class SelfOrganizingStrategy(TrafficLightStrategy):
    """the traffic light with at least *threshold* cars
    times time steps gets to turn green. If no light has
    that many cars, don't switch"""
    threshold = 41
    def __init__(self):
        TrafficLightStrategy.__init__(self)
        # set of lights -> sum over time of number of cars approaching
        self.k_by_s = dict()
    def advance(self, dt, t, independent_sets):
        for s in independent_sets:
            k = self.k_by_s.setdefault(s, 0)
            k += sum(len(light.cars) for light in s)
            self.k_by_s[s] = k
    def select(self, independent_sets):
        s = max(independent_sets, key=lambda s: self.k_by_s.setdefault(s, 0))
        if self.k_by_s.setdefault(s, 0) > SelfOrganizingStrategy.threshold:
            self.k_by_s = dict()
            return s
        return None

class CherryPickingStrategy(TrafficLightStrategy):
    """like greedy, but does not obey the partition; it builds its own
    set of green lights instead"""
    def select(self, independent_sets):
        candidates = list(chain(*independent_sets))
        winners = set()
        while candidates:
            w = max(candidates, key=lambda c: len(c.cars))
            winners.add(w)
            candidates.remove(w)
            candidates = [c for c in candidates if not any(w for w in winners if c.road.intersects(w.road))]
        return winners

class MaxSpeedStrategy(TrafficLightStrategy):
    """the traffic light with the fastest 
    average car speed can witch to green"""
    def select(self, independent_sets):
        out = None, None
        for s in independent_sets:
            nCars = sum(len(l.cars) for l in s)
            avg_speed = sum([car.v for light in s for car in light.cars]) / nCars if nCars else 0
            if avg_speed > out[0]:
                out = avg_speed, s
        return out[1]


class MinSpeedStrategy(TrafficLightStrategy):
    """the traffic light with the slowest 
    average car speed can witch to green"""
    def select(self, independent_sets):
        out = inf, None
        for s in independent_sets:
            nCars = sum(len(l.cars) for l in s)
            avg_speed = sum([car.v for light in s for car in light.cars]) / nCars if nCars else 0
            if avg_speed < out[0]:
                out = avg_speed, s
        return out[1]


class WaitTimeStrategy(TrafficLightStrategy):
    """minimizing wait times: the car that waited longest may go though first"""
    def __init__(self):
        TrafficLightStrategy.__init__(self)
        self.wait_times = {}
    def update_wait_times(self, cars):
        wait_times_new = {} 
        for car in cars:
            wait_times_new[id(car)] = (1, car)
        for key in self.wait_times:
            if key in wait_times_new:
                wait_times_new[key] = (self.wait_times[key][0] + 1, self.wait_times[key][1])
        self.wait_times = wait_times_new
    def get_longest_waiting_car(self):
        out = None, None
        for key in self.wait_times:
            if self.wait_times[key][0] > out[0]:
                out = self.wait_times[key]
        return out[1]
    def select(self, independent_sets):
        cars = [car for s in independent_sets for light in s for car in light.cars]
        if not cars:
            return random.choice(independent_sets)
        self.update_wait_times(cars)
        car = self.get_longest_waiting_car()
        for s in independent_sets:
            if car in [c for light in s for c in light.cars]:
                return s


class TrafficDensityStrategy(TrafficLightStrategy): 
    """minimizing traffic density: the light with the road with the highest 
    car density in front of it may switch to green. Looks further than lookahead."""
    def traffic_density(self, traffic_light_set):
        roads_done = []
        densities = [0]
        for light in traffic_light_set:
            for car in light.cars:
                if car.road not in roads_done:
                    density = len(car.road.cars) / car.road.length()
                    densities.append(density)
                    roads_done.append(car.road)
                    break
        return sum(densities) / len(densities)
    def select(self, independent_sets):
        out = None, None
        for s in independent_sets:
            d = self.traffic_density(s)
            if d > out[0]:
                out = d, s
        return out[1]

class AllGreenStrategy(TrafficLightStrategy):
    def select(self, independent_sets):
        out = set()
        for s in independent_sets:
            out = out.union(s)
        return out


