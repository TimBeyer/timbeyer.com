from operator import methodcaller, itemgetter
from math import fsum, ceil
from collections import deque
from numpy import array, histogram, mean, std, median
from scipy.stats import ks_2samp
from itertools import islice, product, chain, combinations, repeat
from functools import partial
from random import randint
import operator

class Observer(object):
    def __init__(self, m, simulation_count, statfn):
        self.m = m
        self.simulation_count = simulation_count
        self.statfn = statfn

        # map of simulation -> j
        self.simulation_index = dict()

        # list of lists with observations[i][j] being the observation
        # at time step i in simulation j
        self.observations = []
    def __repr__(self):
        return repr({ 'observations': self.observations,
                      'm': self.m,
                      'statfn': self.statfn })
    def observe(self, simulation):
        j = self.simulation_index.setdefault(simulation, len(self.simulation_index))
        # have to hack away here because we don't know which time step we're at
        if not self.observations or self.observations[-1][j] is not None:
            if self.observations:
                print "%4d/%4d [%s]" % (len(self.observations), self.m, \
                                            (" %1.2f" * self.simulation_count) % tuple(self.observations[-1]))
            # new time step, new placeholder for observations
            self.observations.append([None for i in range(self.simulation_count)])
        self.observations[-1][j] = self.statfn(simulation)
    def done(self):
        return len(self.observations) >= self.m
    def batches(self, size, offset=0):
        xs = self.observations
        n = len(xs)
        return list(chain(*(zip(*xs[i:i+size]) for i in range(offset, n - size + 1, size))))
    def batch_means(self, size, offset=0):
        return map(mean, self.batches(size, offset))
    def moving_averages(self, w):
        xs = map(mean, self.observations)
        n = len(xs)
        return [mean(xs[max(0, i-w):i]) for i in range(n % w, n)]
