inf = float("inf")

class SpeedLimit(object):
    def __init__(self, dx, v):
        self.dx = dx
        self.v = v
    def __str__(self):
        return "SpeedLimit<dx %sm v %sm/s>" % (self.dx, self.v)
    def enter_vision(self):
        pass
    def leave_vision(self):
        pass

# a variable speed limit that is 0 or inf based on the state of a
# traffic light and the car's proximity to it
class TrafficLightLimit(SpeedLimit):
    def __init__(self, dx, light, car):
        self.dx = dx
        self.v = inf
        self.light = light
        self.car = car
    def enter_vision(self):
        self.light.cars.add(self.car)
        self.light.subscribe(self.react_to_light)
        self.react_to_light()
    def leave_vision(self):
        self.light.unsubscribe(self.react_to_light)
        self.light.cars.remove(self.car)
    def react_to_light(self):
        self.v = 0 if self.car.driver.stops_for_light(self.light, self.dx, self.car.v) else inf
