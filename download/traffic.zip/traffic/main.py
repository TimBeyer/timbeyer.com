from math import ceil
import random, sys
#random.seed(0)

from datetime import datetime
from vector import dot
from math import ceil, sqrt
import math
from animation import Animation
from cache import cache
from maps import *

from observer import Observer
from operator import methodcaller
from traceback import print_exc
from util import input_number
from numpy import mean, var, histogram
from itertools import chain
from functools import partial
from simulation import Simulation
from strategies import *
from onetruemap import one_true_map

# Logging stuff
import logging
logger = logging.getLogger('main')
#hdlr = logging.FileHandler('main.log')
hdlr = logging.StreamHandler(sys.__stdout__)
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s %(pathname)s:%(lineno)s')
hdlr.setFormatter(formatter)
logger.addHandler(hdlr)
logger.setLevel(logging.ERROR)


def main():


    #roadmap = manhattanoid(size=6, scale=10, strategy=SelfOrganizingStrategy)
    roadmap = quadrilateraloid(size=6,strategy=CherryPickingStrategy)

    #roadmap = manhattanoid_with_turning_lanes(size=4, scale=10, strategy=CherryPickingStrategy)

    simulation = Simulation(roadmap, 200, populate_instantly=True)

    animation = Animation(roadmap)
    animation.start(simulation, 0.5)

def strategies_experiment():
    strategies = [RandomStrategy, GreedyStrategy, SelfOrganizingStrategy,
                    WaitTimeStrategy,
                    TrafficDensityStrategy]
    strategies = [AllGreenStrategy, RandomStrategy, GreedyStrategy,]# WaitTimeStrategy]
    results = []
    for strategy in strategies:
        roadmap = manhattanoid(size=1, scale=25, strategy=strategy)
        simulation = Simulation(roadmap, 1000)
        res = []
        #while len(simulation.cars) < 100:
        while simulation.age < 500:
            simulation.advance(0.1)
            if round(simulation.age*10) % 10 == 0:
                res.append(len(simulation.cars))
        results.append(res)
        print 'done with', strategy.__name__
    import matplotlib.pyplot as plt
    fig = plt.figure()
    ax = fig.add_subplot(111)
    lines = []
    for r in results:
        a = ax.plot(range(len(r)), r)
        lines.append(a)
    plt.figlegend(lines, [i.__name__ for i in strategies], 'upper right')

    plt.show()

# plot multiple statistics of the same simulation
# (to compare convergence)
def compare_statistics():
    from matplotlib.pyplot import plot, show, legend
    statistics = "avg_delay avg_velocity mov_avg_throughput".split()
    dt = 0.5
    n = 10
    m = 100
    observers = [Observer(m, n, methodcaller(statistic)) for statistic in statistics]
    simulations = [Simulation(manhattanoid(size=2, scale=10, strategy=SelfOrganizingStrategy), 100,
                              observers=observers, populate_instantly=False) for i in range(n)]
    while not observers[0].done():
        while not observers[0].done():
            for simulation in simulations:
                simulation.advance(dt)

        raw_input("press return to plot the curves:")

        w = 10
        while w:
            print "plotting moving average with window size %s" % w
            [plot(o.moving_averages(w), label=s) for (s, o) in zip(statistics, observers)]
            legend()
            show()
            w = input_number(int, "plot again with window size (0 to move on, >%s to enlarge m): " % m)
            if w > m:
                m = w
                for observer in observers:
                    observer.m = w
                break

# measure some combinations of statistics and strategies
# allows you to change the number of cars along the way
def fucking_everything_man():
    from matplotlib.pyplot import plot, show, legend, subplot, subplots_adjust
    statistics = "avg_delay avg_velocity throughput".split()
    strategies = [RandomStrategy, GreedyStrategy, SelfOrganizingStrategy]
    dt = 0.5
    n = 3
    m = 100
    ncars = 100

    obss_by_strategy = dict()
    sims_by_strategy = dict()
    for strategy in strategies:
        obss_by_strategy[strategy] = [Observer(m, n, methodcaller(statistic))
                                      for statistic in statistics]
        sims_by_strategy[strategy] = [Simulation(one_true_map(strategy), ncars,
                                                 observers=obss_by_strategy[strategy], populate_instantly=False)
                                      for i in range(n)]

    # all observers will have equally many observations all the time
    # just grab one and use it to test progress
    arb_observer = obss_by_strategy[strategies[0]][0]

    while not arb_observer.done():
        while not arb_observer.done():
            for simulation in chain(*sims_by_strategy.values()):
                simulation.advance(dt)

        raw_input("press return to plot the curves:")

        w = 10
        while w:
            print "plotting moving average with window size %s" % w
            for (strategy, observers) in obss_by_strategy.items():
                for (i, statistic) in enumerate(statistics):
                    subplot(len(statistics), 1, i)
                    plot(observers[i].moving_averages(w), label=strategy.__name__)
                    legend()
            subplots_adjust(bottom = 0, top = 1)
            show()
            w = input_number(int, "plot again with window size (0 to move on): ")

        ncars += input_number(int, "number of cars to add to the simulations (currently %s): " % ncars)
        for simulation in chain(*sims_by_strategy.values()):
            simulation.ncars = ncars

        m += input_number(int, "number of additional observations (0 to quit): ")
        for observer in chain(*obss_by_strategy.values()):
            observer.m = m

def loadmap(map):
    roadmap = json_map_import(map, 5)
    simulation = Simulation(roadmap, 50)
    animation = Animation(roadmap)
    animation.start(simulation, 0.1)

def profile(func):
    import cProfile as profile
    import pstats
    profile.run('%s()' % func.__name__, 'profile')
    p = pstats.Stats('profile')
    p.strip_dirs().sort_stats('time').print_stats()

def boost(f):
    import psyco
    #psyco.log()
    psyco.full()
    f()

def fast_loop():
    sim_dt = 0.1
    roadmap = quadrilateraloid(size=10)
    sim = Simulation(roadmap, 1000)
    ani = Animation(roadmap)
    ani.gui_setup()
    while True:
        for frames in range(int(ani.clock.get_fps())): 
            sim.advance(sim_dt)
            cache.clear()
        ani.update(sim)


def sim_only():
    from pygame.time import Clock
    clock = Clock()
    simulation = Simulation(quadrilateraloid(size=10), 500)
    #while len(simulation.cars) < 200:
    while simulation.age < 240:
        simulation.advance(0.1)
        ncars = len(simulation.cars)
        if ncars % 10 == 0:
            print ' ' * 20 + '\r',
            print '%2.ffps %.0fs %scars\r' % (clock.get_fps(), simulation.age, ncars),
        clock.tick()
        cache.clear()

def threaded():
    from threading import Thread, RLock
    sim_dt = 0.1
    roadmap = quadrilateraloid(size=10)
    sim = Simulation(roadmap, 1000)
    ani = Animation(roadmap)
    ani.gui_setup()
    lock = RLock()
    def loop_sim():
        while True:
            with lock:
                sim.advance(sim_dt)
                cache.clear()
    def loop_ani():
        while True:
            with lock:
                ani.update(sim)
    t1 = Thread(target=loop_sim)
    t2 = Thread(target=loop_ani)
    t1.start()
    print 'sim started'
    t2.start()
    print 'ani started'
    t1.join()
    t2.join()



if __name__ == '__main__':
    main()
    #compare_statistics()
    #fucking_everything_man()
    #loadmap('testmap.json')
    #profile(sim_only)
    #boost(main)
    #fast_loop()
    #sim_only()
    #threaded()
    #strategies_experiment()

