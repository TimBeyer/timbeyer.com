from models import IDM
from math import sqrt
from collections import deque

inf = float("inf")

class CarDriver(object):
    def __init__(self, model):
        self.model = model
        self.vehicle = None
        self.T = 1.2 # s: time headway
        self.a = 0.9 # ms^-2: max acceleration
        self.b = 0.8 # ms^-2: comfortable deceleration
        
        self.v0 = 13.9 #m/s , ~50 kph (desired speed)

        self.s0 = 1. # m: min gap
        self.s1 = 10. # m: min gap when driving

    def can_stop_within(self, dx, v):
        return v**2/(2*self.b) < dx

    def stops_for_light(self, light, dx, v):
        return light.is_red() or (light.is_yellow() and self.can_stop_within(dx, v))

    def get_acceleration(self, limits, current_limit, v, s, delta_v):
        if s == 0:
            return -inf

        # stop if within 1 meter of stopping point
        # (self.b may be slightly too little deceleration to stop in
        # time due numerical instability and discretization.  but at
        # this point you can't brake too much, so just slap a factor
        # 2 on it.)
        if any(limit.v == 0 and limit.dx < 1 for limit in limits):
           return -inf if v != 0 else 0

        # desire the velocity at which, were it the current velocity,
        # you could comfortably decelerate the most pressing limit,
        # reaching the required velocity exactly dx from here
        self.v0 = min([sqrt(limit.v*limit.v + 2*self.b*limit.dx) for limit in limits]+[current_limit])

        # get acceleration from model
        return self.model.acceleration(self.v0, v, s, delta_v, self.s0, self.s1)
