import sys
from datetime import datetime
from traceback import print_exc
from pprint import pprint
from util import input_number
from matplotlib.pyplot import plot, show

from math import ceil, sqrt, pow
from numpy import mean, var, histogram
from vector import dot

from operator import methodcaller
from itertools import chain
from functools import partial

from simulation import Simulation
from observer import Observer
from onetruemap import one_true_map
from strategies import *
import strategies

def measure(strategy, statistic, number_of_cars):
    threshold = 41 # keep this in a separate local variable so it will show up in locals()
    SelfOrganizingStrategy.threshold = threshold

    def save_data(variables):
        filename = 'measurements\\%s_%s_%s_%s' % (strategy.__name__, statistic, number_of_cars, datetime.now().isoformat().replace(':', ''))
        print 'saving data in %s.' % filename
        f = open(filename, 'w')
        pprint(variables, f)
        f.close()
        print 'saved.'

    try:
        # we need n independent simulations with m observations each
        # to be able to determine the warmup time l.  m should be
        # greater than what you expect l to be (though you get a
        # chance to enlarge it later)
        dt = 0.5
        n = 10
        default_m = 1000

        observer = Observer(default_m, n, methodcaller(statistic))
        simulations = [Simulation(one_true_map(strategy), number_of_cars,
                                  observers=[observer], populate_instantly=True) for i in range(n)]

        while not observer.done():
            while not observer.done():
                for simulation in simulations:
                    simulation.advance(dt)

            raw_input('press return to plot the curve:')

            w = 10
            # allow the user to pick w a couple of times
            while w:
                print 'plotting moving average with window size %s' % w
                plot(observer.moving_averages(w))
                show()
                w = input_number(int, 'plot again with window size (0 to move on, >%s to enlarge m): ' % observer.m)
                if w > observer.m:
                    observer.m = w
                    break

        l = input_number(int, 'enter l: ')

        # let a batch span five simulation minutes
        bs = 5 * 60 / Simulation.observation_dt

        # fix this at 20 and P* at 0.9
        dd_n0 = 20
        # fix this once we decide on k (the number of strategies to compare)
        # for now it's a nice upper bound for P* = 0.9
        dd_h1 = 2.747 # <-- k = 5     3.182 # k = 10
        # i have no idea
        dd_d = 1e-2 * mean(map(mean, observer.observations))

        # compute total number of observations needed to meet dd_n0
        dd_n0_m = l + int(ceil(float(dd_n0) / n)) * bs
        dm = dd_n0_m - len(observer.observations)
        print 'need %s more observations to get n0 batch means.' % (dm if dm > 0 else 'no')
        observer.m = dd_n0_m

        # get the observations
        while not observer.done():
            for simulation in simulations:
                simulation.advance(dt)

        dd_X0s = observer.batch_means(bs, offset=l)[0:dd_n0]
        dd_X0 = mean(dd_X0s)
        dd_V0 = var(dd_X0s)
        print 'the n0 batch means have mean %2.3f and stdev %2.4f' % (dd_X0, sqrt(dd_V0))

        while True:
            # compute D&D
            dd_N = max(dd_n0 + 1, int(ceil(pow(dd_h1, 2)*dd_V0/pow(dd_d, 2))))
            dd_N_m = l + int(ceil(float(dd_N) / n)) * bs

            dm = dd_N_m - len(observer.observations)
            print 'need %s more observations to get N = %s batch means.' % (dm if dm > 0 else 'no', dd_N)
        
            _dd_d = input_number(float, 'enter value for d* (0 to move on using current value %2.5f): ' % dd_d)
            if _dd_d == 0:
                break
            else:
                dd_d = _dd_d
        
        observer.m = dd_N_m
        
        # get the rest of the observations
        while not observer.done():
            for simulation in simulations:
                simulation.advance(dt)

        # compute the weights and weighted mean
        raspberries = (dd_N-dd_n0)*pow(dd_d, 2) / (pow(dd_h1, 2)*dd_V0)
        dd_w0 = (dd_n0*1.0/dd_N) * (1 + sqrt(1 - (dd_N*1.0/dd_n0)*(1 - raspberries)))
        dd_w1 = 1 - dd_w0

        dd_X1s = observer.batch_means(bs, offset=l)[dd_n0:dd_N]
        dd_X1 = mean(dd_X1s)

        xs = list(chain(dd_X0s, dd_X1s))

        # drum roll....
        dd_ws = (dd_w0, dd_w1)
        dd_Xs = (dd_X0, dd_X1)

        # and voila!
        dd_X = dot(dd_ws, dd_Xs)

        print 'batch means histogram: %4.2f %s %4.2f' % (min(xs), histogram(xs)[0], max(xs))
        print 'grand sample mean: %f' % mean(xs)
        print 'weighted sample mean X~(%d): %f' % (len(xs), dd_X)

        save_data(locals())
    except:
        # to the lifeboats!
        print_exc()
        print 'something went horribly wrong.'
        try:
            save_data(locals())
        except:
            print_exc()
            print 'yet another thing went horribly wrong.  take this REPL, brother; may it serve you well.'
            while True:
                try:
                    print(eval(raw_input('>>> ')))
                except:
                    print_exc()
                    print 'whoops! try again.'

if __name__ == '__main__':
    if len(sys.argv) < 4:
        print 'usage: python %s strategy statistic number_of_cars' % sys.argv[0]
        raise SystemExit

    try:
        strategy = getattr(strategies, sys.argv[1])
    except AttributeError:
        print 'strategy must be the name of one of the classes in strategies.py'
        raise SystemExit

    statistics = 'cum_avg_delay avg_velocity cum_avg_throughput'.split()
    statistic = sys.argv[2]
    if not statistic in statistics:
        print 'statistic must be one of %s' % statistics
        raise SystemExit

    try:
        number_of_cars = int(sys.argv[3])
        if number_of_cars <= 0:
            raise ValueError
    except ValueError:
        print 'number of cars must be a positive integer'
        raise SystemExit

    measure(strategy, statistic, number_of_cars)
