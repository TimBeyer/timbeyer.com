import math
import random
from operator import methodcaller

from vector import plus, minus, times, over, dot, transform, norm, unit, distance


inf = float("inf")

class RoadMap(object):
    def __init__(self, roads, systems=set(), name=None, dims=0):
        self.roads = roads
        self.systems = systems
        self.name = name
        self.dims = dims

        xmin =  inf
        ymin =  inf
        xmax = -inf
        ymax = -inf

        self.roads_by_start = {}
        self.roads_by_end = {}
        self.road_by_start_and_end = {}

        for road in roads:
            xmin = min(xmin, road.start[0], road.end[0])
            ymin = min(ymin, road.start[1], road.end[1])
            xmax = max(xmax, road.start[0], road.end[0])
            ymax = max(ymax, road.start[1], road.end[1])

            self.roads_by_start.setdefault(road.start, set()).add(road)
            self.roads_by_end  .setdefault(road.end,   set()).add(road)
            self.road_by_start_and_end[(road.start, road.end)] = road

        self.origin = (xmin, ymin)
        self.size   = minus((xmax, ymax), self.origin)

        self.ins  = set(road.start for road in roads
                        if road.start not in self.roads_by_end)
        self.outs = set(road.end   for road in roads
                        if road.end   not in self.roads_by_start)
                        
        self.road_grid = MapGrid(self)
        
    def roads_from(self, start):
        return self.roads_by_start.get(start, set())
    def roads_to(self, end):
        return self.roads_by_end.get(end, set())
    def road_between(self, start, end):
        return self.road_by_start_and_end.get((start, end), None)
    def random_entrance(self):
        free_entrances = [entrance for entrance in self.ins if self.roads_by_start[entrance].copy().pop().permission_to_land()]
        #free_entrances = [road.start for road in self.roads if road.permission_to_land()]
        return random.sample(free_entrances, 1)[0] if free_entrances else None
    def random_exit(self):
        return random.sample(self.outs, 1)[0] if self.outs else None
    def roads_near_pos(self, pos):
        return self.road_grid.get_objects_at(self.road_grid.map_to_grid_coords(pos))

    def advance(self, dt, t):
        map(methodcaller('advance', dt, t), self.systems)
       

class MapGrid(object):
    def __init__(self, roadmap, h_res=100):
        self.roadmap = roadmap
        self.aspect_ratio = float(self.roadmap.size[0]) / self.roadmap.size[1]
        self.res = (h_res, int(math.ceil(h_res / self.aspect_ratio)))
        self.cell_dims = [self.roadmap.size[0] / self.res[0] for i in range(2)]
        self.grid = {}
        
        for road in self.roadmap.roads:
            self.add_object_along_line(road, self.map_to_grid_coords(road.start), self.map_to_grid_coords(road.end))
        
    def map_to_grid_coords(self, map_coords):
        grid_coords = tuple(int(min(math.floor(map_coords[i] / self.cell_dims[i]), self.res[0])) for i in range(2))
        return grid_coords
        
    def add_object_at(self, obj, coords):
        if not coords in self.grid:
            self.grid[coords] = []
        self.grid[coords].append(obj)
        
    def remove_object_at(self, obj, coords):
        if coords in self.grid:
            if obj in self.grid[coords]:
                self.grid[coords].remove(obj)
        
    def get_objects_at(self, coords):
        if coords in self.grid:
            return self.grid[coords]
        
    def add_object_along_line(self, obj, start_coords, end_coords):
        # http://en.wikipedia.org/wiki/Bresenham's_line_algorithm#Generalization
        x0, y0 = start_coords
        x1, y1 = end_coords
        if x0 == x1 and y0 == y1:
            self.add_object_at(obj,(x0, y0))
            return
        steep = abs(y1 - y0) > abs(x1 - x0)
        if steep:
            x0, y0 = y0, x0
            x1, y1 = y1, x1
        if x0 > x1:
            x0, x1 = x1, x0
            y0, y1 = y1, y0
        deltax = x1 - x0
        deltay = abs(y1 - y0)
        
        error = 0.
        deltaerr = float(deltay) / deltax
        y = y0
        ystep = 1 if y0 < y1 else -1
        for x in range(x0,x1):
            if steep:
                self.add_object_at(obj,(y,x))
            else:
                self.add_object_at(obj,(x,y))
            error = error + deltaerr
            if error >= 0.5:
                y += ystep
                error -= 1.0        
                
            
