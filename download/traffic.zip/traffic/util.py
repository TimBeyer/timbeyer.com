inf = float("inf")
from functools import partial
from itertools import repeat
import operator
from vector import plus, times, minus, over

def cache(fn):
    memory = dict()
    def cached(*args):
        if args not in memory:
            memory[args] = fn(*args)
        return memory[args]
    return cached

def test_cache():
    def fib(i):
        if   i == 0: return 0
        elif i == 1: return 1
        else: return fib(i-1) + fib(i-2)
    f = fib
    g = cache(fib)
    assert(all(f(i) == g(i) for i in xrange(0, 20)))

def smallest_graph_colorings(vs, adjacent, color_limit=None):
    for k in xrange(1, len(vs)+1 if color_limit is None else color_limit+1):
        colorings = graph_colorings(vs, adjacent, color_limit=k)
        if len(colorings) > 0:
            return colorings

def graph_colorings(vs, adjacent, coloring=frozenset(), color_limit=inf):
    if len(vs) == 0:
        return set([coloring])
    colorings = set()
    v = next(iter(vs))
    for ws in coloring:
        if not any(map(partial(adjacent, v), ws)):
            colorings |= graph_colorings(vs-set([v]),
                                         adjacent,
                                         (coloring-set([ws])) | set([ws|set([v])]),
                                         color_limit)
    if len(coloring) < color_limit:
        colorings |= graph_colorings(vs-set([v]),
                                     adjacent,
                                     coloring | set([frozenset([v])]),
                                     color_limit)
    return colorings

#print smallest_graph_coloring(set(xrange(1,16)), lambda x, y: x%2 != y%2, 2)

def lines_intersect(l, m):
    # http://www.bryceboe.com/2006/10/23/line-segment-intersection-algorithm/
    # (does not report colinear lines as intersecting)
    def ccw(A,B,C):
	   return (C[1]-A[1])*(B[0]-A[0]) > (B[1]-A[1])*(C[0]-A[0])
    def intersect(A,B,C,D):
        return ccw(A,C,D) != ccw(B,C,D) and ccw(A,B,C) != ccw(A,B,D)
    return intersect(l[0], l[1], m[0], m[1])

def input_number(parse, prompt):
    while True:
        try:
            return parse(raw_input(prompt))
        except ValueError as e:
            print e

def normalize_series(xs, xmin, xmax):
    try:
        return map(partial(operator.mul, 1/float(xmax - xmin)),
                   map(partial(operator.add, -xmin), xs))
    except ZeroDivisionError:
        if xmax - xmin == 0:
            return [0]*len(xs)
        else:
            raise

