import logging

from math import sqrt, isinf, fabs
from cache import cache
from collections import deque
from itertools import chain
from operator import methodcaller, attrgetter
from limit import SpeedLimit, TrafficLightLimit

logger = logging.getLogger('main')
inf = float("inf")
nan = float("NaN")

class Car(object):
    def __init__(self, driver, route):
        self.x = 0
        self.v = 0
        self.a = 0

        self.driver = driver
        self.lookahead = 50
        self.route = route

        self.stopped = False

        # these are used to compute the test statistic (self.delay()),
        # and are maintained as we go along.
        self.ideal_travel_time   = 0
        self.travel_time         = 0
        self.distance_traveled   = 0
        self.lights_passed_count = 1 # count one light ahead

        # limits within lookahead distance.
        # since the lookahead distance may be time-variant in the
        # future, it is not necessarily true that the limits in
        # self.limits are all within lookahead distance.  at best we
        # can say that these lights were at some limit within
        # lookahead distance.  this inaccuracy is not a problem
        # because lookahead is only limited to ease computation.
        self.limits = deque()

        # similar to self.limits, but contains all limits on the
        # planned route that are not (or rather, have never yet been)
        # within lookahead distance.  this needs to be computed after
        # each route change (so currently only once per car).
        self.all_limits = self.limits_along_route()
        self.discover_limits()

        # this modifies the route, and so should come after the calls to
        # xx_along_route().
        self.road = self.route.pop_next_road()
        if self.road:
            self.road.insert_car(self)

        
    def delay(self):
        if self.distance_traveled != 0 and self.lights_passed_count != 0:
            return (self.travel_time - self.ideal_travel_time) / sqrt(self.distance_traveled * self.lights_passed_count)
        else:
            return 0
    def __str__(self):
        return "Car(id %s x %s v %s on road %s)" % (id(self), self.x, self.v, id(self.road))
    def done(self):
        return not self.road
    def advance(self, dt, t):
        if self.done():
            return

        self.travel_time += dt

        dcif = self.dcif()
        if(dcif[0] < self.driver.s1 + 1 and fabs(dcif[1]) < 1 and self.v < 0.4):
            self.a = 0
            self.v = 0
            self.stopped = True
            return 
        else:
            self.stopped = False

        self.a = self.driver.get_acceleration(self.limits, self.road.limit, self.v, *dcif)

        # no backward movement
        # also special-case infinite deceleration or we won't be able to
        # compute dt0 later
        if self.a < 0 and (self.v == 0 or isinf(self.a)):
            self.v = 0
            return

        # dx should be computed from the "old" velocity, so keep
        # the velocity update after the computation of dx
        dx = self.v*dt + self.a*0.5*dt**2
        dv = self.a*dt

        if self.v + dv < 0:
            # figure out where in the last dt seconds the car was
            # supposed to stop
            dt0 = -self.v/self.a
            dx = self.v*dt0 + self.a*0.5*dt0**2
            self.v = 0
        else:
            self.v += dv

        self.x += dx

        self.ideal_travel_time += dx / self.road.limit
        self.distance_traveled += dx

        for limit in chain(self.limits, self.all_limits):
            limit.dx -= dx
        self.discover_limits()

        next_road = self.next_road_maybe()
        if next_road is not self.road:
            self.road.remove_car(self)
            self.road = next_road
            if self.road is not None:
                self.road.insert_car(self)

    def next_road_maybe(self):
        road = self.road
        while road and self.x > road.length():
            self.x -= road.length()
            road = self.route.pop_next_road()
        return road

    # look ahead and if necessary move limits from self.all_limits
    # to self.limits, and remove passed limits from self.limits
    def discover_limits(self):
        while self.all_limits and self.all_limits[0].dx < self.lookahead:
            limit = self.all_limits.popleft()
            self.limits.append(limit)
            limit.enter_vision()
        while self.limits and self.limits[0].dx <= 0:
            limit = self.limits.popleft()
            if hasattr(limit, 'light'):
                self.lights_passed_count += 1
            limit.leave_vision()
    def limits_along_route(self):
        limits = deque()
        x = 0
        for road in self.route:
            limits.append(SpeedLimit(x, road.limit))
            if road.light:
                limits.append(TrafficLightLimit(x, road.light, self))
            x += road.length()
        return limits
    def abspos(self):
        return self.road.abspos(self.x) # shouldn't get here if not self.road
    # returns (dx, dv) to car in front
    # (note: dx is self.x - cif.x whereas dv is cif.v - self.v)
    # (note: I don't know who came up with that)
    def dcif(self):
        cif = self.road.car_in_front_of(self)
        if cif:
            return (cif.x - self.x, self.v - cif.v)
        else:
            none = (inf, 0)
            dx = self.road.length() - self.x
            for road in self.route:
                if dx >= self.lookahead:
                    return none
                cif = road.first_car
                if cif:
                    dx += cif.x
                    dv = self.v - cif.v
                    return (dx, dv)
                dx += road.length()
            return none
