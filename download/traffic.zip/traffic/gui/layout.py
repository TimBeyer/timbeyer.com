

class Layout(object):
	def __init__(self):
		self.components = []

	def add_component(self, component):
		pass
	
	def remove_component(self, component):
		self.components.remove(component)
		self.recalculate()
	
	def recalculate(self):
		pass


class StackedLayout(Layout):
	def __init__(self, margin_left=2, margin_top=2):
		super(StackedLayout,self).__init__()
		self.margin_left = margin_left
		self.margin_top = margin_top
		self.last_component_y = 0
		self.last_component_height = 0

	def add_component(self, component):
		self.components.append(component)
		position = ( 
						self.margin_left, 
						self.last_component_y + self.last_component_height + self.margin_top
					)
		self.last_component_y = position[1]
		self.last_component_height = component.dimensions[1]
		component.set_position(position)

	def remove_component(self, component):
		self.last_component_y = 0
		self.last_component_height = 0
		super(StackedLayout, self).remove_component()

	def recalculate(self):
		copy = [component for component in self.components]
		self.components = []
		for component in copy:
			self.add_component(component)


class HorizontalLayout(Layout): 
	def __init__(self, margin_left=2, margin_top=2):
		super(HorizontalLayout,self).__init__()
		self.margin_left = margin_left
		self.margin_top = margin_top
		self.last_component_x = 0
		self.last_component_width = 0

	def add_component(self, component):
		self.components.append(component)
		position = ( 
						self.last_component_x + self.last_component_width + self.margin_left,
						self.margin_top
					)
		self.last_component_x = position[0]
		self.last_component_width = component.dimensions[0]
		component.set_position(position)

	def remove_component(self, component):
		self.last_component_x = 0
		self.last_component_width = 0
		super(StackedLayout, self).remove_component()

	def recalculate(self):
		copy = [component for component in self.components]
		self.components = []
		for component in copy:
			self.add_component(component)



