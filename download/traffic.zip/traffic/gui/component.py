import math
import pygame
import random
from time import time

from cache import cache
from collections import deque
from vector import plus, minus, times, over, dot, transform, norm, unit, distance
from itertools import islice, starmap
from functools import partial
from operator import itemgetter
from util import normalize_series
import operator

from layout import StackedLayout, HorizontalLayout

from maps import *
from strategies import *
from storage import Storage

transparent = pygame.Color(1,1,1)


class Component(object):
    def __init__(self, animation, dimensions, zindex=1):
        self.animation = animation
        self.surface = pygame.Surface(dimensions).convert()
        self.parent_surface = None
        self.parent = None
        self.child_components = []
        self.dimensions = dimensions
        self.position = (0,0)
        self.zindex = zindex
        self.background_color = transparent
        self.highlight_color = pygame.Color(120,120,120)


    def set_position(self, position):
        self.position = position
        self.update()
        #self.draw()
    def set_dimensions(self, dimensions):
        self.dimensions = dimensions
        self.surface = pygame.Surface(dimensions).convert()
        for surface in self.child_components:
            surface.parent_surface = self.surface
        self.update()
    def receive_click(self, coords):
        position = self.position
        parent = self.parent
        while parent is not None:
            position = plus(position, parent.position)
            parent = parent.parent
        if position[0] < coords[0] < position[0] + self.dimensions[0] and\
            position[1] < coords[1] < position[1] + self.dimensions[1]:
            relative_position = minus(coords, position)
            self.handle_click(relative_position)

            for component in self.child_components:
                component.receive_click(coords)


    def handle_click(self, coords):
        pass
    def add_child(self, child):
        self.child_components.append(child)
        child.parent_surface = self.surface#self.surface.subsurface(pygame.Rect(child.position, child.dimensions))
        child.parent = self
    def remove_child(self, child):
        self.child_components.remove(child)
    @property
    def width(self):
        return self.dimensions[0]
    @property
    def height(self):
        return self.dimensions[1]
    def resize(self, dimensions):
        self.dimensions = dimensions
        self.update()
    def get(self):
        return self.surface
    def update(self):
        self.surface.fill(self.background_color)
        for child in self.child_components:
            child.update()
        self.surface.set_colorkey(transparent)

    def auto_resize(self):
        for component in self.child_components:
            component.auto_resize() 
        
    def draw(self):

        self.child_components.sort(key=lambda s: s.zindex)
        for surface in self.child_components:
            surface.draw()
        self.parent_surface.blit(self.surface, self.position)

    def draw_text_at(self, text, position, size=10, right_align=False):
        font = pygame.font.SysFont("Verdana", size)
        font_surface = font.render(text, True, pygame.Color('white'))
        if right_align:
            position = position[0] - font_surface.get_width(), position[1]
        self.surface.blit(font_surface, position)
        
class Sidebar(Component):
    def __init__(self, animation, dimensions, zindex=1):
        super(Sidebar, self).__init__(animation, dimensions, zindex=zindex)
        self.animation = animation
        self.element_spacing = 20
        self.padding = 10
        self.update_rate = 1
        self.update_counter = 0

        self.background_color = pygame.Color(45,43,43)
        self.margin_left = 2
        self.margin_top = 2

        self.layout = StackedLayout(margin_left = self.margin_left, margin_top = self.margin_top)

        simclock = SimClock(self.animation, (self.dimensions[0] - 2 * self.margin_left,50))
        self.layout.add_component(simclock)
        self.add_child(simclock)

        # Add information displays
        for i, name in enumerate(self.animation.stats):
            lgraph = LiveGraph(self.animation, (self.dimensions[0] - 2 * self.margin_left,90), i, label=name)
            self.layout.add_component(lgraph)
            self.add_child(lgraph)

        roadgraph = RoadDetails(self.animation, (self.dimensions[0] - 2 * self.margin_left, 160))
        self.layout.add_component(roadgraph)
        self.add_child(roadgraph)
        
        overview = Overview(self.animation, (self.dimensions[0] - 2 * self.margin_left,200), self.animation.roadmap, zindex=1)  
        self.layout.add_component(overview)
        self.add_child(overview)

    
    def auto_resize(self):
        super(Sidebar, self).auto_resize()
        self.set_dimensions((self.animation.sidebar_width, self.animation.viewport_size[1]))
        self.set_position((self.animation.viewport_size[0] - self.animation.sidebar_width, 20))

    def update(self):
        super(Sidebar, self).update()
        self.surface.set_alpha(220)
           
    
    def instant_update(self):
        self.update_counter = self.update_rate - 1
        self.update()


    def draw_graph_at(self, position, width):
        road = self.animation.selected_road
        scale = width / road.length()
        pygame.draw.line(self.surface, pygame.Color('white'), position, plus(position, (width,0)))
        for car in road.cars:
            color = pygame.Color('white')
            if car.a < 0:
                scalar = min(-4 * car.a, 1)
                hue = int(min(255 - scalar * 255, 255))
                color = pygame.Color(255, hue, hue)
            else: 
                scalar = min(car.a / car.driver.a, 1)
                hue = int(min(255 - scalar * 255, 255))
                color = pygame.Color(hue, hue, 255)
            
            car_x_scaled = car.x * scale
            car_y_scaled = car.v / self.animation.top_speed * -50
            draw_coords = plus(position, (car_x_scaled, 0))
            pygame.draw.line(self.surface, color, draw_coords, plus(draw_coords, (0,car_y_scaled)))

class SimClock(Component):
    def __init__(self, animation, dimensions, zindex=1):
        super(SimClock, self).__init__(animation, dimensions, zindex=zindex)
        self.gradient = pygame.image.load('gui/images/gradient.png')
        self.gradient.convert_alpha()

    def update(self):
        self.surface.fill(pygame.Color('black'))
        age = self.animation.simulation.age
        minutes, seconds = int(age / 60), age % 60
        sim_time = "%02d:%02ds" % (minutes, seconds)
        self.draw_text_at(sim_time, (self.dimensions[0] - 5,2), size=36, right_align=True)


class RoadDetails(Component):
    def __init__(self, animation, dimensions, zindex=1):
        super(RoadDetails, self).__init__(animation, dimensions, zindex=zindex)
        self.gradient = pygame.image.load('gui/images/gradient.png')
        self.gradient.convert_alpha()
        self.label = 'Road'
        self.label_height = 22
        self.element_spacing = 12
         
    def update(self):
        self.surface.fill(pygame.Color('black'))
        road = self.animation.selected_road
        self.draw_text_at("%s" % (self.label),
                  (10,3), 10)
        if road:
            self.draw_text_at("ID: %s" % id(road), (self.dimensions[0]-2,3), 10, right_align=True)
            scale = self.dimensions[0] / road.length()
            position = (0,self.dimensions[1] - 10)
            pygame.draw.line(self.surface, pygame.Color('white'), position, plus(position, (self.dimensions[0],0)))
            for car in road.cars:
                color = pygame.Color('white')
                if car.a < 0:
                    scalar = min(-4 * car.a, 1)
                    hue = int(min(255 - scalar * 255, 255))
                    color = pygame.Color(255, hue, hue)
                else: 
                    scalar = min(car.a / car.driver.a, 1)
                    hue = int(min(255 - scalar * 255, 255))
                    color = pygame.Color(hue, hue, 255)
                
                car_x_scaled = car.x * scale
                car_y_scaled = car.v / self.animation.top_speed * -50
                draw_coords = plus(position, (car_x_scaled, 0))
                pygame.draw.line(self.surface, color, draw_coords, plus(draw_coords, (0,car_y_scaled)))
            text_queue =   [("Length", "%.0fm" % road.length()),
                            ("Cars on road", "%s" % len(road.cars)),
                            ("Density", "%.0f cars/km" % road.traffic_density()),
                            ("Avg Speed", "%.2fm/s" % (sum(car.v for car in road.cars)/len(road.cars) if road.cars else 0)),
                            ("Max Speed", "%.2fm/s" % (max(car.v for car in road.cars) if road.cars else 0))]
            for i, (text_l, text_r) in enumerate(text_queue):
                self.draw_text_at(text_l, (10, i*self.element_spacing + 25))
                self.draw_text_at(text_r, (self.surface.get_width()-2, i*self.element_spacing + 25), right_align=True)
        else:
            self.draw_text_at("Select a road for details",(40,self.label_height + 20))
        for x in xrange(self.dimensions[0]):
            self.surface.blit(self.gradient, (x,self.label_height))

class Overview(Component):
    def __init__(self, animation, dimensions, roadmap, zindex=1):
        super(Overview, self).__init__(animation, dimensions, zindex=zindex)
        self.roadmap = roadmap
        self.map_size = animation.map_size
        self.gradient = pygame.image.load('gui/images/gradient_large.png')
        self.gradient.convert_alpha()


    def update(self):
        super(Overview, self).update()

        self.surface.fill(pygame.Color('black'))
        #self._info()
        self._map()
        self._viewport()
        #for x in xrange(self.dimensions[0]):
        #    self.surface.blit(self.gradient, (x,0))
        #self.draw_text_at("%s" % (self.label),
         # (10,3), 10)

    def auto_resize(self):
        super(Overview, self).auto_resize()
        #self.set_position((0, self.animation.viewport_size[1] - self.dimensions[1]))

    def draw(self):
        super(Overview, self).draw()

    def map2overview(self, pos):
        return tuple([float(pos[i]) / self.map_size[i] * self.dimensions[0] for i in range(2)])
    def overview2map(self, pos):
        return tuple([float(pos[i]) * self.map_size[i] / self.dimensions[0] for i in range(2)])
    def handle_click(self, pos):
        coords = self.overview2map(pos)
        self.animation.center_view_on(coords)
    def _map(self):
        roads = self.roadmap.roads
        for road in roads:
            density = road.traffic_density()
            hue = min(int(1.5*density+16), 255)
            color = pygame.Color(hue, hue, hue)
            pygame.draw.line(self.surface, color, self.map2overview(road.start), self.map2overview(road.end))
    def _viewport(self):
        vp_offset = self.animation.viewport_offset
        vp_size = self.animation.viewport_size
        map_offset = self.animation.map_offset
        scale = self.animation.scale
        sidebar = self.animation.sidebar_width, 0
        origin = self.map2overview(over(plus(vp_offset, map_offset),scale))
        dims = self.map2overview(over(minus(vp_size, sidebar), scale))
        rect = pygame.Rect(origin, dims)
        pygame.draw.rect(self.surface, pygame.Color('yellow'), rect, 1)
    def _info(self):
        self.draw_text_at('scale: %.2f' % self.animation.scale, (0, 0))
        self.draw_text_at('vp offset: (%.0f, %.0f)' % self.animation.viewport_offset, (0, 20))
        self.draw_text_at('vp size: (%.0f, %.0f)' % self.animation.viewport_size, (0, 40))
        self.draw_text_at('map offset: (%.0f, %.0f)' % self.animation.map_offset, (0, 60))
        self.draw_text_at('map size: (%.0f, %.0f)' % self.animation.map_size, (0, 80))

       

class Grid(Component):
    def __init__(self, animation, dimensions, grid, zindex=1):
        super(Grid, self).__init__(animation, dimensions, zindex=zindex)
        self.grid = grid

    def update(self):
        super(Grid, self).update()
        self.surface.fill(pygame.Color('black'))
        dimensions = over(self.dimensions, self.grid.res)
        scale = self.animation.scale
        for coords in self.grid.grid:
            n = len(self.grid.grid[coords])
            hue = min(n * 16, 255)
            #n = int(sum([road.traffic_density() for road in self.grid.grid[coords]]))
            #hue = min(n, 255)
            color = pygame.Color(hue, hue, hue)
            rect = pygame.Rect(times(scale, minus(times(coords, dimensions), self.animation.map_offset)), times(scale, dimensions))
            pygame.draw.rect(self.surface, color, rect)


class LiveGraph(Component):
    def __init__(self, animation, dimensions, stats_index, label='', margin_top = 10, margin_left = 5, zindex=1):
        super(LiveGraph, self).__init__(animation, dimensions, zindex=zindex)
        self.stats = self.animation.stats
        self.stats_index = stats_index
        label = self.animation.stats[self.stats_index]
        if label == 'avg_delay':
            self.label = 'Delay'
        elif label == 'mov_avg_throughput':
            self.label = 'Throughput'
        elif label == 'avg_velocity':
            self.label = 'Average speed'
        else:
            self.label = label
        self.label_height = 22
        self.margin_top = margin_top
        self.margin_left = margin_left
        self.graph_dimensions = (self.dimensions[0] - 2 * self.margin_left, self.dimensions[1] - 2 * self.margin_top - self.label_height)
        self.graph_position = (self.margin_left, self.margin_top + self.label_height)
        self.background_color = pygame.Color('black')
        self.gradient = pygame.image.load('gui/images/gradient.png')
        self.gradient.convert_alpha()

    def update(self):
        super(LiveGraph, self).update()
        self.surface.fill(self.background_color, pygame.Rect((0,0),self.dimensions))
        try:
            ys = normalize_series(map(itemgetter(self.stats_index), self.animation.stats_over_time),
                                    self.animation.stat_min[self.stats_index], self.animation.stat_max[self.stats_index])
            ys = minus(1, ys) # account for y axis inversion
            xs = normalize_series(plus(range(len(ys)), self.animation.stat_timesteps - len(ys)),
                                    0, self.animation.stat_timesteps)
            points = map(partial(plus, self.graph_position),
                            map(partial(times, self.graph_dimensions),
                                zip(xs, ys)))
            self.surface.fill(self.background_color, pygame.Rect((self.graph_position, self.graph_dimensions)))
            pygame.draw.aalines(self.surface, pygame.Color(200, 200, 255), False, points)
            self.surface.fill(pygame.Color(255, 255, 255), pygame.Rect(map(int, map(round, points[-1])), (2, 2)))
            self.curr_number = "%4f" % (self.animation.stats_over_time[-1][self.stats_index])
            #self.curr_number = self.curr_number.rjust(44)
            self.draw_text_at("%s" % (self.label),
                                (10,3), 10)
            self.draw_text_at("%s" % (self.curr_number), (self.dimensions[0]-2,3), 10, right_align=True)
            for x in xrange(self.dimensions[0]):
                self.surface.blit(self.gradient, (x,self.label_height))

        except (ValueError, IndexError):
            if not len(self.animation.stats_over_time) < 2:
                raise

current_choices = Storage({})

class MenuBar(Component):
    def __init__(self, animation, dimensions, zindex=1):
        super(MenuBar, self).__init__(animation, dimensions, zindex=zindex)
        self.layout = HorizontalLayout()

        spacer = Component(animation, dimensions, zindex=0)
        spacer.dimensions = (40,20)

        systems = animation.simulation.roadmap.systems
        name = animation.roadmap.name
        current_choices = Storage({})
        current_choices.ncars = animation.simulation.ncars
        current_choices.strategy = type(systems.copy().pop().strategy) if systems else CherryPickingStrategy
        current_choices.roadmap = eval(name) if name else manhattanoid_with_turning_lanes
        current_choices.size = animation.roadmap.dims or 4
        

        self.layout.add_component(spacer)
        self.add_child(spacer)

        drop_down_map = DropDownMenu(self.animation, (80,300), 'Map')
        self.layout.add_component(drop_down_map)
        self.add_child(drop_down_map)

        maps = []
        maps.append(('Manhattanoid', manhattanoid_with_turning_lanes))
        maps.append(('ManhattanSimple',  manhattanoid))
        maps.append(('Quad', quadrilateraloid))
        maps.append(('QuadSimple', quadrilateraloid_unregulated))
        maps.append(('JSON', json_map_import))

        def map_funct(rmap):
            def funct(pos):
                current_choices.roadmap = rmap
            return funct
        
        for (name, rmap) in maps:
            selected = True if current_choices.roadmap == rmap else False
            map_button = ButtonComponent(animation, (80,20), name, map_funct(rmap), selected=selected, drop_down=drop_down_map)
            drop_down_map.add_item(map_button)

        drop_down_size = DropDownMenu(self.animation, (80,300), 'Size')
        self.layout.add_component(drop_down_size)
        self.add_child(drop_down_size)

        def size_funct(n):
            def funct(pos):
                current_choices.size = n
            return funct

        for i in range(1,10):
            selected = True if current_choices.size == i else False
            size_button = ButtonComponent(animation, (80,20), str(i), size_funct(i), selected=selected, drop_down=drop_down_size)
            drop_down_size.add_item(size_button)
            
        drop_down_ncars = DropDownMenu(self.animation, (80,300), 'Cars')
        self.layout.add_component(drop_down_ncars)
        self.add_child(drop_down_ncars)

        def ncars_funct(n):
            def funct(pos):
                current_choices.ncars = n
            return funct

        for i in range(100,1000,200):
            selected = True if current_choices.ncars == i else False
            ncars_button = ButtonComponent(animation, (80,20), str(i), ncars_funct(i), selected=selected, drop_down=drop_down_ncars)
            drop_down_ncars.add_item(ncars_button)

        drop_down_strat = DropDownMenu(self.animation, (80,300), 'Strategy')
        self.layout.add_component(drop_down_strat)
        self.add_child(drop_down_strat)

        strategies = []
        strategies.append(('Cherry', CherryPickingStrategy))
        strategies.append(('Random', RandomStrategy))
        strategies.append(('Greedy', GreedyStrategy))
        strategies.append(('SelfOrg', SelfOrganizingStrategy))
        strategies.append(('Fire Sale', AllGreenStrategy))

        def strat_funct(strat):
            def funct(pos):
                current_choices.strategy = strat
            return funct
        
        for (name, strat) in strategies:
            selected = True if current_choices.strategy == strat else False
            strat_button = ButtonComponent(animation, (80,20), name, strat_funct(strat), selected=selected, drop_down=drop_down_strat)
            drop_down_strat.add_item(strat_button)


        apply_button = ButtonComponent(animation,(80,20), 'GO', 
                        lambda pos: self.animation.restart(**current_choices))
        self.layout.add_component(apply_button)
        self.add_child(apply_button)



    def update(self):
        super(MenuBar, self).update()
        pygame.draw.rect(self.surface, pygame.Color(50,50,50), pygame.Rect(self.position, (self.dimensions[0], 24)))

    def auto_resize(self):
        super(MenuBar, self).auto_resize()
        self.set_dimensions(( self.animation.viewport_size[0],self.dimensions[1]))

    

class TextComponent(Component):
    def __init__(self, animation, dimensions, callback, zindex=1):
        super(TextComponent, self).__init__(animation, dimensions, zindex=zindex)
        self.callback = callback
    def update(self):
        super(TextComponent, self).update()
        self.surface.fill(transparent)
        self.draw_text_at(self.callback(), (2,2), 10)
    def handle_click(self, pos):
        #self.animation.restart()
        pass

class ButtonComponent(Component):
    def __init__(self, animation, dimensions, caption, callback, zindex=1, selected=False, drop_down = None):
        super(ButtonComponent, self).__init__(animation, dimensions, zindex=zindex)
        self.callback = callback
        self.caption = caption
        self.selected = selected
        self.drop_down = drop_down

    def update(self):
        super(ButtonComponent, self).update()
        if self.selected:
            self.surface.fill(self.highlight_color)
        else:
            self.surface.fill(self.background_color)
        self.draw_text_at(self.caption, (2,2), 10)

    def handle_click(self, pos):
        if self.drop_down is not None:
            for component in self.drop_down.menu_pane.child_components:
                if component.selected:
                    component.selected = False
        self.selected = True if not self.selected else False
        self.animation.gui_update(self.animation.simulation)
        self.callback(pos)

class DropDownMenu(Component):
    def __init__(self, animation, dimensions, caption, zindex=1):
        super(DropDownMenu, self).__init__(animation, dimensions, zindex=zindex)
        self.caption = caption
        self.menu_pane_offset = 24
        self.menu_pane = Component(self.animation, self.dimensions)
        self.menu_pane.position = (0,self.menu_pane_offset)
        self.menu_pane.layout = StackedLayout()
        self.show_menu = False

    def add_item(self, component):
        self.menu_pane.add_child(component)
        self.menu_pane.layout.add_component(component)
        component.background_color = pygame.Color(77,77,77)

    def update(self):
        super(DropDownMenu, self).update()
        self.draw_text_at(self.caption, (2,2))

    def handle_click(self,pos):
        self.show_menu = not self.show_menu
        if(self.show_menu):
            self.add_child(self.menu_pane)
        else:
            self.remove_child(self.menu_pane)

    def receive_click(self, coords):
        position = self.position
        parent = self.parent
        while parent is not None:
            position = plus(position, parent.position)
            parent = parent.parent
        if position[0] < coords[0] < position[0] + self.dimensions[0] and\
            position[1] < coords[1] < position[1] + self.menu_pane_offset:
            relative_position = minus(coords, position)
            self.handle_click(relative_position)
        elif position[0] < coords[0] < position[0] + self.dimensions[0] and\
                position[1] < coords[1] < position[1] + self.dimensions[1]:
            relative_position = minus(coords, position)   
            for component in self.child_components:
                component.receive_click(coords)




