import logging
import operator
from collections import deque

from cache import permacache
from vector import plus, minus, times, norm, unit
from util import lines_intersect
from lights import TrafficLight


logger = logging.getLogger('main')

class Road(object):
    def __init__(self, start, end, limit=13.9, light=False):
        self.start = start
        self.end = end
        self.light = TrafficLight(self) if light else None
        self.limit = limit

        displacement = minus(self.end, self.start)
        self._length = norm(displacement)
        self._direction = unit(displacement)

        self.first_car = None
        self.last_car = None
        self.cars = deque()
        
    def __str__(self):
        return self.__repr__()
    def __repr__(self):
        return "Road(%s, %s)" % (self.start, self.end)
    def length(self):
        return self._length
    @permacache
    def abspos(self, x):
        return plus(self.start, times(x, self._direction))
    # self.cars is redundant with the doubly-linked list running
    # through the cars.  this method compares the two.  use it when
    # debugging to rule out the possibility of inconsistence.  to rule
    # out the possibility of cars overtaking unofficially (i.e., in
    # terms of car.x but not in terms of order in these structures),
    # assert s >= 0 in driver.get_acceleration.
    def check_sanity(self):
        if self.cars or self.first_car: assert(self.first_car is self.cars[0])
        if self.cars or self.last_car: assert(self.last_car is self.cars[-1])

        cars = []
        car = self.first_car
        while car:
            cars.append(car)
            car = car._next

        assert(all(map(operator.is_, self.cars, cars)))
    def insert_car(self, car):
        self.cars.appendleft(car)
        if not self.first_car:
            self.first_car = car
            self.last_car = car
            car._prev = None
            car._next = None
        elif car.x <= self.first_car.x:
            self.first_car._prev = car
            car._next = self.first_car
            car._prev = None
            self.first_car = car
        else:
            logging.error("attempted insertion of car %s which is ahead of first_car %s" % (car, self.first_car))
    def remove_car(self, car):
        if car is self.last_car:
            self.cars.pop()
            if not car._prev:
                self.first_car = None
                self.last_car = None
                car._next = None
            else:
                self.last_car = car._prev
                self.last_car._next = None
                car._prev = None
        else:
            logging.error("attempted removal of car %s which is not last_car %s" % (car, self.last_car))
    def car_in_front_of(self, car):
        return car._next
    def traffic_density(self):
        return len(self.cars) / self._length * 1000 # cars/km
    def permission_to_land(self):
        return  (not self.first_car or self.first_car.x > 1) \
            and (not self.light or self.light.is_green())
    def intersects(self, road):
        return Road.intersect(self, road)
    @staticmethod
    def intersect(a, b):
        if a is b:
            return False
        elif a.start == b.start:
            return False 
        elif a.end == b.end:
            return True
        else:
            return lines_intersect((a.start, a.end),
                                   (b.start, b.end))
