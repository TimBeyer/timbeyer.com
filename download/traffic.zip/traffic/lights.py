from operator import methodcaller, attrgetter
from itertools import groupby, chain

from strategies import *
from util import smallest_graph_colorings

class TrafficLight(object):
    def __init__(self, road):
        self.road = road
        self.cars = set()
        self.subscribers = set()
        self.state = 'RED'
    def __repr__(self):
        return '<TrafficLight %s: %s>' % (id(self), self.state)
    def subscribe(self, fn):
        self.subscribers.add(fn)
    def unsubscribe(self, fn):
        self.subscribers.remove(fn)
    def is_state(self, state):
        return self.state == state
    def set_state(self, state):
        self.state = state
        map(methodcaller('__call__'), self.subscribers)
    def switch(self):
        states = {'RED': 'GREEN', 'GREEN': 'YELLOW', 'YELLOW': 'RED'}
        self.set_state(states[self.state])
    def set_green(self):
        self.set_state('GREEN')
    def set_yellow(self):
        self.set_state('YELLOW')
    def set_red(self):
        self.set_state('RED')
    def is_green(self):
        return self.is_state('GREEN')
    def is_yellow(self):
        return self.is_state('YELLOW')
    def is_red(self):
        return self.is_state('RED')


class TrafficLightSystem(object):
    def __init__(self, traffic_lights, strategy=None, partitioned=False):
        if strategy is None:
            self.strategy = TrafficDensityStrategy()
        else:
            self.strategy = strategy()

        self.traffic_lights = set(chain(*traffic_lights) if partitioned else traffic_lights)
        self.independent_sets = list(traffic_lights if partitioned else self._find_independent_sets(traffic_lights))
        self.open_lights = random.choice(self.independent_sets)
        self.next_set = None

        self.switch_to('GREEN')
        self.last_switch_time = 0
    def switch_to(self, phase):
        for light in self.open_lights:
            light.set_state(phase)
        self.phase = phase
    def __str__(self):
        return '<TrafficLightSystem %s: red %s yellow %s green %s>' % \
            (id(self),
             len(self.traffic_lights) - len(self.open_lights),
             len(self.open_lights) if any(light.is_yellow() for light in self.open_lights) else 0,
             len(self.open_lights) if any(light.is_green()  for light in self.open_lights) else 0)
    def _find_independent_sets(self, lights):
        """returns independent sets of traffic lights, 
        ie. ones that can be green at the same time"""
        # high if the lights are grouped by their roads' start points,
        # low if the start points are scattered throughout the groups.
        # (prevents cars on the same road going in different directions
        # from having to wait for eachother's lights to turn green)
        def samesourceness(coloring):
            ngs = 0
            for vs in coloring:
                vs = list(vs)
                vs.sort(key=lambda light: light.road.start)
                for k, g in groupby(vs, lambda light: light.road.start):
                    ngs += 1
            return 1.0/ngs
        colorings = smallest_graph_colorings(lights, lambda l, m: l.road.intersects(m.road))
        return max(colorings, key=samesourceness)
    def advance(self, dt, global_time):
        # allow the strategy to do some bookkeeping
        self.strategy.advance(dt, global_time, self.independent_sets)

        lapsed_time = global_time - self.last_switch_time 
        if lapsed_time >= self.strategy.min_yellow_time and self.phase == 'YELLOW':
            self.switch_to('RED')
            self.open_lights = self.next_set
            self.next_set = None
            self.switch_to('GREEN')
            self.last_switch_time = global_time
        elif lapsed_time >= self.strategy.min_green_time and self.phase == 'GREEN':
            self.next_set = self.strategy.select(self.independent_sets)
            # strategies can return None to indicate not to switch
            if self.next_set is None or self.next_set == self.open_lights:
                # pretend we switched
                self.next_set = None
            else:
                self.switch_to('YELLOW')
            self.last_switch_time = global_time

def test():
    from road import Road
    roads = set([Road(e[0], e[1])
             for e in [(( 0,-1), (0, 1)),
                       ((-1, 0), (1, 0))]])
    lights = set()
    for road in roads:
        light = TrafficLight(road)
        lights.add(light)
        road.light = light
    strategy = RandomStrategy()
    #strategy = GreedyStrategy()
    tls = TrafficLightSystem(lights, strategy)
    dt = 1
    t = 0
    for i in range(120):
        t += dt
        tls.advance(dt, t)
        print tls


if __name__ == '__main__':
    test()



