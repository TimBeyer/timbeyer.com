from math import sqrt
from numbers import Number
from collections import Sequence
from functools import partial
import operator

# Because numpy's vectors are crap, here's some more bearable linear
# algebra functionality.  Use tuples for vectors; they are interned and
# hashable.

# element-wise arithmetic: plus, times, minus, over
def plus(*xs):
    scalars = filter(operator.isNumberType, xs)
    scalar = reduce(operator.add, scalars, 0)
    if len(scalars) == len(xs):
        return scalar
    vectors = filter(operator.isSequenceType, xs)
    vector = reduce(partial(map, operator.add), vectors)
    return tuple(map(partial(operator.add, scalar), vector))
def times(*xs):
    scalars = filter(operator.isNumberType, xs)
    scalar = reduce(operator.mul, scalars, 1)
    if len(scalars) == len(xs):
        return scalar
    vectors = filter(operator.isSequenceType, xs)
    vector = reduce(partial(map, operator.mul), vectors)
    return tuple(map(partial(operator.mul, scalar), vector))

# minus and over have to be treated specially because the first element
# is special: minus(x, *ys) == plus(x, times(-1, plus(*ys)))
# (these are slightly slower than plus and times)

# passing 0 or 1 as initializer to reduce here slows it down for some reason
def minus(*xs): return reduce(biminus, xs) if xs else 0
def  over(*xs): return reduce(biover,  xs) if xs else 1

def biminus(x, y):
    xv = isinstance(x, Sequence)
    yv = isinstance(y, Sequence)
    if xv and yv: return tuple(map(operator.sub, x, y))
    if xv: return tuple(x - y for x in x)
    if yv: return tuple(x - y for y in y)
    return x - y
def biover(x, y):
    xv = isinstance(x, Sequence)
    yv = isinstance(y, Sequence)
    if xv and yv: return tuple(map(operator.div, x, y))
    if xv: return tuple(x / y for x in x)
    if yv: return tuple(x / y for y in y)
    return x / y

# higher-level operations
def dot(v, w):
    # assume v, w vectors
    return sum(map(operator.mul, v, w))

def transform(x, A):
    # assume x vector, A matrix
    return tuple(map(partial(dot, x), A))

def norm(v):
    return sqrt(dot(v, v))

def unit(v):
    return over(v, norm(v))

def distance(p, q):
    return norm(minus(p, q))

