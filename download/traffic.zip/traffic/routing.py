import operator
from collections import deque
from functools import partial
from Queue import PriorityQueue

from vector import distance

astar_cache = {}


def empty_cache():
    astar_cache = {}
    
def AStar(initial,
          successorfn=lambda x: x, pathcostfn=lambda x: x,
          heuristicfn=lambda x: x, goaltestfn=lambda x: x):
    # Python lists can't share structure and so are inefficient in time
    # and space for keeping track of the tentative path.  Instead, we
    # can build Lispy lists using 2-tuples as conses.  Once we're done
    # searching, we can turn the Lispy list into a regular Python list
    # using the procedure below.
    def listify(tl):
        l = []
        while tl is not None:
            l.append(tl[0])
            tl = tl[1]
        return l
    seen = set()
    fringe = PriorityQueue()
    # Fringe elements are of the form (f(x), g(x), ws(x), x), where
    #   x is the node under consideration,
    #   f(x), g(x) are A*'s usual functions of x, and
    #   ws(x) is a Lispy list of the tentative path, in reverse order
    fringe.put((0, 0, None, initial))
    while not fringe.empty():
        (fx,gx,ws,x) = fringe.get()
        if x not in seen:
            seen.add(x)
            if goaltestfn(x):
                path = listify(ws)
                path.reverse()
                return path
            for y in successorfn(x):
                gy = gx + pathcostfn(x, y)
                hy = heuristicfn(y)
                fringe.put((gy + hy, gy, (y, ws), y))
    return []

class Route(object):
    def __init__(self, roadmap, source, destination):
        self.roadmap = roadmap
        self.source = source
        self.destination = destination
        self._route = self.plan()
    
    def plan(self):
        key = (self.source, self.destination)
        def pathcostfn(p, q):
            # The cumulative path cost must always dominate over the
            # heuristic function for the latter to be admissible.  This
            # condition is satisfied; traffic density and 1/limit are
            # always >= 0.
            road = self.roadmap.road_between(p, q)
            return road.length() * (1 + 10 * road.traffic_density() + 1 / road.limit)
            #return road.length() * (1)
          
        if key in astar_cache:
            ends = astar_cache[key]
        else:
            # the search algorithm returns the points visited in order.  we
            # need to turn this into a queue of roads before returning.
            ends = AStar(self.source,
                         successorfn=lambda p: map(operator.attrgetter('end'), self.roadmap.roads_from(p)),
                         heuristicfn=partial(distance, self.destination),
                         pathcostfn=pathcostfn,
                         goaltestfn=partial(operator.eq, self.destination))
            astar_cache[key] = ends               

        starts = list(ends)
        starts.insert(0, self.source)
        starts.pop()
        return deque(map(self.roadmap.road_between, starts, ends))

    def __len__(self):
        return len(self._route)

    def __iter__(self):
        for road in self._route:
            yield road

    def pop_next_road(self):
        return self._route.popleft() if self._route else None
