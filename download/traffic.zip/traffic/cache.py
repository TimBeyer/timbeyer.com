

class Cache(object):

    def __init__(self):
        self._cache = {}

    def clear(self):
        self._cache = {}

    def __call__(self, f):
        def func(*args, **kwargs):
            kw = kwargs.items()
            kw.sort()
            key = (f.__name__, args, tuple(kw))
            if key in self._cache:
                #print 'hit'
                result = self._cache[key]
            else:
                #print 'miss'
                result = self._cache[key] = f(*args,**kwargs)
            return result
        func.func_name = f.func_name
        return func

class DummyCache(object): 
    def clear(self):
        pass
    def __call__(self, f):
        def func(*args, **kwargs):
            return f(*args,**kwargs)

#print 'instantiating caches'
cache = Cache()#DummyCache()
permacache = Cache()#DummyCache()

